adjustment_0.adj_param_0.center:  0
adjustment_0.adj_param_0.description:  x_offset
adjustment_0.adj_param_0.lock_flag:  0
adjustment_0.adj_param_0.parameter:  0
adjustment_0.adj_param_0.sigma:  20
adjustment_0.adj_param_0.units:  unknown
adjustment_0.adj_param_1.center:  0
adjustment_0.adj_param_1.description:  y_offset
adjustment_0.adj_param_1.lock_flag:  0
adjustment_0.adj_param_1.parameter:  0
adjustment_0.adj_param_1.sigma:  20
adjustment_0.adj_param_1.units:  unknown
adjustment_0.adj_param_2.center:  0
adjustment_0.adj_param_2.description:  orientation x
adjustment_0.adj_param_2.lock_flag:  0
adjustment_0.adj_param_2.parameter:  0
adjustment_0.adj_param_2.sigma:  0.1
adjustment_0.adj_param_2.units:  degrees
adjustment_0.adj_param_3.center:  0
adjustment_0.adj_param_3.description:  orientation y
adjustment_0.adj_param_3.lock_flag:  0
adjustment_0.adj_param_3.parameter:  0
adjustment_0.adj_param_3.sigma:  0.1
adjustment_0.adj_param_3.units:  degrees
adjustment_0.adj_param_4.center:  0
adjustment_0.adj_param_4.description:  orientation z
adjustment_0.adj_param_4.lock_flag:  0
adjustment_0.adj_param_4.parameter:  0
adjustment_0.adj_param_4.sigma:  0.1
adjustment_0.adj_param_4.units:  degrees
adjustment_0.adj_param_5.center:  0
adjustment_0.adj_param_5.description:  Altitude delta
adjustment_0.adj_param_5.lock_flag:  0
adjustment_0.adj_param_5.parameter:  0
adjustment_0.adj_param_5.sigma:  50
adjustment_0.adj_param_5.units:  meters
adjustment_0.description:  Initial adjustment
adjustment_0.dirty_flag:  0
adjustment_0.number_of_params:  6
bore_sight_tx:  21.185
bore_sight_ty:  3.394
bore_sight_tz:  -21.69
ce90_absolute:  0
ce90_relative:  0
current_adjustment:  0
distortion.center:  0 0
distortion.convergence_threshold:  1e-05
distortion.dxdy:  0.0052 0.0052
distortion.k0:  -3.31047898329193e-08
distortion.k1:  -1.43768392130338e-05
distortion.k2:  3.03977248401731e-09
distortion.k3:  6.97378568618727e-13
distortion.max_iterations:  10
distortion.type:  ossimMeanRadialLensDistortion
ecef_platform_position:  1287659.23999478 -5014338.06962693 3713690.17620128
focal_length:  51.597
image_id:  C25870220
kappa:  26.40248
latlonh_platform_position:  35.8358336435943 -75.597898447446 427.790101242409 WGE
ll_lat:  35.8333470710207
ll_lon:  -75.5993719300932
lr_lat:  35.8353404077805
lr_lon:  -75.5944828196241
meters_per_pixel_x:  0.0472667406629875
meters_per_pixel_y:  0.0472667406629875
number_lines:  0
number_of_adjustments:  1
number_samples:  0
omega:  0.08755
phi:  -0.3929
pixel_size:  0.0052 0.0052
principal_point:  0.014 0.083
rect:  0 0 10327 7759
ref_point_hgt:  -41.1918158177286
ref_point_lat:  35.8358336879789
ref_point_line:  3880
ref_point_lon:  -75.5978604039942
ref_point_samp:  5164
sensor:  sn580_12314900
shift_values:  0 0 0
type:  ossimApplanixUtmModel
ul_lat:  35.836322730935
ul_lon:  -75.6012100270705
ur_lat:  35.8383348140887
ur_lon:  -75.5963406305857
utm_hemisphere:  N
utm_platform_position:  446001.06 3965905.211 427.790101242409 WGE
utm_zone:  18
